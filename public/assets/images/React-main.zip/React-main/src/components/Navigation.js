// import React from "react";
// export default function Navigation() {
//     return (
//         <nav>
//             <ul>
//                 <li><a className='active' href="#home">Home</a></li>
//                 <li><a href="#news">News</a></li>
//                 <li><a href="#about">About</a></li>
//                 <li><a href="#contact">Contact</a></li>
//             </ul>
//         </nav>
//     )
// }

import React from 'react'
import { useContext } from 'react'
import { ThemeContext } from './ThemeContext'
import { Link } from 'react-router-dom'
import { Navbar, NavItem, Icon } from 'react-materialize'


export default function Navigation() {
    const { theme, toggle, dark } = useContext(ThemeContext)
    return (
        <div>
            <Navbar className='menu'
                alignLinks="right"
                brand={<span className="brand-logo">Player Cards</span>}
                id="mobile-nav"
                menuIcon={<Icon>menu</Icon>}
            >

                <nav style={{ backgroundColor: theme.backgroundColor, color: theme.color }}>
                    <div>
                        <ul>
                            <li><Link to='/'><Icon left>home</Icon>Home</Link></li>
                            <li><Link to='/about'><Icon left>info_outline</Icon>About</Link></li>
                            <li><Link to='/new'><Icon left>dvr</Icon>News</Link></li>
                            <li><Link to='/contact'><Icon left>contacts</Icon>Contact</Link></li>
                        </ul>
                    </div>
                </nav>

            </Navbar>




            <div style={{ position: 'relative' }}>
                <a className='switch-mode' onClick={toggle}
                    style={{
                        backgroundColor: theme.backgroundColor,
                        color: theme.color,
                        outline: 'none',
                        cursor: 'pointer',
                    }} data-testid="toggle-theme-btn"
                >
                    Switch Nav to {!dark ? 'Dark' : 'Light'} mode
                </a>
            </div>

        </div >
    )
}
