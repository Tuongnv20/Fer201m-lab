import React from "react";

const Home = () => {
    return (
        <h1>Home page content</h1>
    )
}

export default Home;