import React from "react";
import { Players } from "../shared/ListOfPlayers";
import { useState } from "react";
import { Link } from "react-router-dom";
import { Icon, CardTitle, Row, Col, Card, Container } from 'react-materialize'



export default function Player() {

    const [player, setPlayer] = useState([]);
    return (
        <div className="container">
            {Players.map((p) => (
                <div className="column" key={p.id}>
                    <div className="card">
                        <img src={p.img} />
                        <h3>{p.name}</h3>
                        <p className='title'>{p.club}</p>
                        {/* <button onClick={() => { setPlayer(p) }}>
                            <a href='#popup1' id='openPopUp'>Detail</a>
                        </button> */}
                        <Link to={`detail/${p.id}`}>
                            <p><button>Detail</button></p>
                        </Link>
                    </div>
                </div>
            ))}
            {/* <div id='popup1' className="overlay" >
                <div className="popup">
                    <img src={player.img} />
                    <h2>{player.name}</h2>
                    <a className="close" href="#">&times;</a>
                    <div className="content">
                        {player.info}
                    </div>
                </div>
            </div> */}
        </div>
    )
}

