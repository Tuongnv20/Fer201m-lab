
import './App.css';
import Navigation from './components/Navigation';
import Footer from './components/Footer';
import {
  Routes,
  Route,
} from "react-router-dom";
import Player from './components/Players';
import Detail from './components/Detail';
import Contact from './components/Contact';
import Home from './components/Home';



function App() {
  return (
    <div className='App'>
      <div className='app-header'>
        <Navigation />
      </div>
      <div className='app-content'>

        <Routes>
          <Route path='/' element={<Player />}>
          </Route>
          <Route path='/detail/:id' element={<Detail />}></Route>
          <Route path='/contact' element={<Contact />}></Route>
        </Routes>

      </div>
      <div className='footer'>
        <Footer />
      </div>

    </div>
  );
}

export default App;